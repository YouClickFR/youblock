var script = document.createElement('script');
script.src = 'https://code.jquery.com/jquery-3.2.1.min.js';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);

function getScore(title) {
	var tmp = null;
	$.ajax({
		async: false,
		type: "POST",
		global: false,
		crossDomain: true,
		dataType: "html",
		data: { 'request': "", 'target': 'arrange_url', 'method': 'method_target' },
		url:  "https://youclick.fr/?onlytitle=true&title="+title,
		success: function (data) {
			tmp = data;
		}
	});
	return tmp;
}
function removeElem(el){
	if(el==null){return;}
	if(el.tagName=="YTD-COMPACT-VIDEO-RENDERER"||el.tagName=="LI"||el.tagName=="YTD-GRID-VIDEO-RENDERER"||el.tagName=="YTD-VIDEO-RENDERER"){
		$(el).attr("style","display:none;")
	}else{
		try{
		removeElem(el.parentNode);
		}catch(err){console.log(err);}
	}
}
function blurElem(el){
	if(el==null){return;}
	if(el.tagName=="YTD-COMPACT-VIDEO-RENDERER"||el.tagName=="LI"||el.tagName=="YTD-GRID-VIDEO-RENDERER"||el.tagName=="YTD-VIDEO-RENDERER"){
		$(el).addClass("blurred");
	}else{
		try{
		blurElem(el.parentNode);
		}catch(err){}
	}
}
function waiter(){
	setTimeout(1000,function(){return true});
}
if(localStorage.timer){
	clearInterval(localStorage.timer);
}
chrome.storage.local.get(function(result){
	localStorage.timer=setInterval(function(){
		main();
	},result.interval*1000);
});
chrome.runtime.sendMessage({videonull: true}, function(response) {});
function main(){
	$(document).ready();
	var style;
	var excreators;
	var exstrings;
	var limitgray;
	var limitremove;
	var defined = false;
	
	chrome.storage.local.get(function(stored){
		style = stored.style;
		excreators = stored.excreators || "";
		excreators = excreators.split("/n");
		exstrings = stored.exstrings || "";
		exstrings = exstrings.split("/n");
		limitgray = stored.gray;
		limitremove = stored.remove;
		defined = true;
		
		var watch = (window.location.href.indexOf("watch")!=-1);

		if (watch){
			var titles = $("span.title");
			var creators = $("span.stat span.g-hovercard");
			if(titles.length<1){
				var titles = $("h3.style-scope.ytd-compact-video-renderer span.style-scope.ytd-compact-video-renderer");
				var creators = $("div.style-scope.ytd-video-meta-block yt-formatted-string.style-scope.ytd-video-meta-block");
			}
		}else{
			var titles = $(".yt-ui-ellipsis.yt-ui-ellipsis-2.yt-uix-sessionlink.spf-link");
			var creators = $(".g-hovercard.yt-uix-sessionlink.spf-link");
			if(titles.length<1){
				var titles = $(".yt-simple-endpoint.style-scope.ytd-grid-video-renderer, .yt-simple-endpoint.style-scope.ytd-video-renderer");
				var creators = $(".yt-simple-endpoint.style-scope.yt-formatted-string").not("bold").toArray();
				creators.pop();
				creators.pop();
				creators = $(creators);
			}
		}
		
		while(!defined){
			console.log(waiter());
		}
		console.log(excreators);
		console.log(exstrings);
		console.log(limitgray);
		console.log(limitremove);
		titles.each(function(i) {
			if($(titles[i]).prop("analysed")) return true;
			var titleText = $(titles[i]).text();
			console.log(titleText);
			$.each(exstrings, function(i,value){
				if(titleText.toLowerCase().indexOf(value.toLowerCase)!=-1) {
					removeElem(titles[i]);
				}
			});
			var score = getScore(titleText);
			$(titles[i]).text("["+score+"] "+titleText);
			score = +score;
			var edited = false;
			if(excreators.indexOf($(creators[i]).text())!=-1) {
				removeElem(titles[i]);
				edited = true;
			}
			if (score>limitgray){
				blurElem(titles[i]);
				edited = true;
			}
			if (score>limitremove){
				removeElem(titles[i]);
				edited = true;
			}
			if(edited) {
				chrome.runtime.sendMessage({videoplus: true}, function(response) {});
			}
			$(titles[i]).prop("analysed", true);
		});
	});
	
}
main();