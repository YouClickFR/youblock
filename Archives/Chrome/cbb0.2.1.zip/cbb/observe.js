chrome.runtime.onInstalled.addListener(function(details){
    if(details.reason == "install"){
        chrome.storage.local.set({
			gray: 100,
			remove: 130,
			pro: true,
			excreators: null,
			exstrings: null,
			interval: 1.5
		});
    }else{
		chrome.storage.local.get(function(result){
			if(!result.gray) chrome.storage.local.set({gray: 100});
			if(!result.remove) chrome.storage.local.set({remove: 130});
			if(!result.excreators) chrome.storage.local.set({excreators: null});
			if(!result.exstrings) chrome.storage.local.set({exstrings: null});
			if(!result.interval) chrome.storage.local.set({interval: 1.5});
		});
	}
});

chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		console.log(request);
		if (request.videoplus){
			
			chrome.tabs.query({currentWindow: true, active : true},	function(tabs){
				var tabid;
				tabid = tabs[0].id;
				chrome.browserAction.getBadgeText({tabId: tabid},function(badgecount){
					if (!badgecount){
						text = "1";
					}else{
						text = +badgecount+1;
						text = ""+text;
					}
					chrome.browserAction.getBadgeText({},function(badgecount){
					chrome.browserAction.setBadgeText({text: text, tabId: tabid});
					});
				});
			});
			console.log("+1");
			sendResponse({added: "Count +1"});
		}
		if (request.videonull){
			chrome.tabs.query({currentWindow: true, active : true},	function(tabs){
				chrome.browserAction.getBadgeText({},function(badgecount){
				chrome.browserAction.setBadgeText({text: "", tabId: tabs[0].id});
				});
			});
			
			sendResponse({added: "Count 0"});
		}
	}
);