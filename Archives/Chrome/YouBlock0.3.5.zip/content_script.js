
document.onbeforeunload = function(){
    chrome.storage.local.get(function(result){
        if(localStorage.timer){
            clearInterval(localStorage.timer);
        }
    });
};
chrome.storage.local.get(function(result){
    if(result.enabled){
        var script = document.createElement('script');
        script.src = 'https://code.jquery.com/jquery-3.2.1.min.js';
        script.type = 'text/javascript';
        document.getElementsByTagName('head')[0].appendChild(script);

        function getScore(title,id) {
            var tmp = null;
            $.ajax({
                async: false,
                type: "POST",
                global: false,
                crossDomain: true,
                dataType: "html",
                data: { 'request': "", 'target': 'arrange_url', 'method': 'method_target' },
                url:   "https://youclick.fr/analyse.php?onlytitle=true&title="+title+"&videoID="+id,
                success: function (data) {
                    tmp = data;
                }
            });
            return tmp;
        }
        function getId(el){
            if(el.href){
                return el.href.split("?v=")[1].split("&")[0];
            }else{
                return (getId(el.parentNode));
            }
        }
        function removeElem(el,styleNew){
            if(styleNew){
                if(el==null){return;}
                if(el.tagName=="YTD-COMPACT-VIDEO-RENDERER"||el.tagName=="YTD-GRID-VIDEO-RENDERER"||el.tagName=="YTD-VIDEO-RENDERER"){
                    $(el).attr("style","display:none;")
                }else{
                    try{
                    removeElem(el.parentNode,styleNew);
                    }catch(err){console.log(err);}
                }
            }else{
                if(el==null){return;}
                if(el.tagName=="LI"||el.tagName=="TR"){
                    $(el).attr("style","display:none;")
                }else{
                    try{
                    removeElem(el.parentNode,styleNew);
                    }catch(err){console.log(err);}
                }
            }
            
        }
        function blurElem(el, styleNew){
            if(styleNew){
                if(el==null){return;}
                if(el.tagName=="YTD-COMPACT-VIDEO-RENDERER"||el.tagName=="YTD-GRID-VIDEO-RENDERER"||el.tagName=="YTD-VIDEO-RENDERER"){
                    $(el).addClass("blurred");
                }else{
                    try{
                    blurElem(el.parentNode,styleNew);
                    }catch(err){}
                }	
            }else{
                if(el==null){return;}
                if(el.tagName=="LI"||el.tagName=="TR"){
                    $(el).addClass("blurred");
                }else{
                    try{
                    blurElem(el.parentNode,styleNew);
                    }catch(err){}
                }
            }
            
        }
        
        function main(){
            $(document).ready(function(){
            
                var style = result.style;
                var blacklist = result.blacklist || "";
                blacklist = blacklist.split("/n");
                var whitelist = result.whitelist || "";
                whitelist = whitelist.split("/n");
                var limitgray = result.gray;
                var limitremove = result.remove;
                
                var watch = (window.location.href.indexOf("watch")!=-1);
                
                var styleNew = false;
                
                var titles = [];
                var creators = [];
                
                if (watch){
                    titles = $("span.title");
                    creators = $("span.stat span.g-hovercard");
                    if(titles.length<1){
                        titles = $("h3.style-scope.ytd-compact-video-renderer span.style-scope.ytd-compact-video-renderer");
                        creators = $("div.style-scope.ytd-video-meta-block yt-formatted-string.style-scope.ytd-video-meta-block");
                        styleNew = true;
                    }
                }else{
                    titles = $(".yt-ui-ellipsis.yt-ui-ellipsis-2.yt-uix-sessionlink.spf-link, .pl-video-title-link.yt-uix-tile-link.yt-uix-sessionlink.spf-link");
                    creators = $(".g-hovercard.yt-uix-sessionlink.spf-link").not(".shelf-annotation.shelf-title-annotation .g-hovercard.yt-uix-sessionlink.spf-link").not(".branded-page-module-title-link");
                    if(titles.length<1){
                        titles = $("#page-manager .style-scope.ytd-page-manager:last-child .yt-simple-endpoint.style-scope.ytd-grid-video-renderer, #page-manager .style-scope.ytd-page-manager:last-child .yt-simple-endpoint.style-scope.ytd-video-renderer, #page-manager .style-scope.ytd-page-manager:last-child span.style-scope.ytd-playlist-video-renderer");
                        creators = $("#page-manager .style-scope.ytd-page-manager:last-child .yt-simple-endpoint.style-scope.yt-formatted-string").not("bold").toArray();
                        creators.pop();
                        creators.pop();
                        creators = $(creators);
                        styleNew=true;
                    }
                }
                for(i=0;i<creators.length;i++){
                    if(creators[i].innerHTML==""){
                        creators.splice(i,1);
                    }
                }
                while(creators.length<titles.length){
                    creators.push(creators[creators.length-1]);
                }
                console.log(blacklist);
                console.log(whitelist);
                console.log(limitgray);
                console.log(limitremove);
                console.log(titles);
                console.log(creators);
                
                titles.each(function(i) {
                    if($(titles[i]).prop("analysed")) return true;
                    
                    var titleText = $(titles[i]).text();
                    var vidId = getId(titles[i]);
                    var score = getScore(titleText,vidId);
                    console.log(vidId);
                    console.log(titleText);
                    console.log(score);
                    $(titles[i]).text("["+score+"] "+titleText);
                    if ((window.location.href.indexOf("channel")!=-1)&&(typeof creators[i] != "undefined")){
                        if(blacklist.indexOf($(creators[i]).text())!=-1) {
                            removeElem(titles[i]);
                            edited = true;
                            console.log("blacklist");
                        }
                        if((whitelist.indexOf($(creators[i]).text())!=-1)&&(typeof creators[i] != "undefined")) return true;
                    }
                    var edited = false;
                    if (+score>+limitgray){
                        blurElem(titles[i],styleNew);
                        edited = true;
                        console.log("grayed");
                    }
                    if (+score>+limitremove){
                        removeElem(titles[i],styleNew);
                        edited = true;
                        console.log("removed");
                    }
                    if(edited) {
                        chrome.runtime.sendMessage({videoplus: true}, function(response) {});
                    }
                    $(titles[i]).prop("analysed", true);
                });
            });
        }
           
        if(localStorage.timer){
            clearInterval(localStorage.timer);
        }
        localStorage.timer=setInterval(function(){
            main();
        },result.interval*1000);
        chrome.runtime.sendMessage({videonull: true}, function(response) {});

        main();
    }
});
