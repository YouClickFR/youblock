
    document.onbeforeunload = function(){
        chrome.storage.local.get(function(result){
            if(localStorage.timer){
                clearInterval(localStorage.timer);
            }
        });
    };

    chrome.storage.local.get(function(result){
        if(!result.enabled){ return;}
    });
        
    function getScore(title,id) {
        var tmp = null;
        $.ajax({
            async: false,
            type: "POST",
            global: false,
            crossDomain: true,
            dataType: "html",
            data: { 'request': "", 'target': 'arrange_url', 'method': 'method_target' },
            url:   "https://youclick.fr/analyse.php?onlytitle=true&title="+title+"&videoID="+id,
            success: function (data) {
                tmp = data;
            }
        });
        return tmp;
    }
    
    
    function getId(el){
        if(el.href){
            return el.href.split("?v=")[1].split("&")[0];
        }else{
            return (getId(el.parentNode));
        }
    }
    
    
    function getVideoElement(el){
        if(el==null){return null;}
        if(el.tagName=="YTD-COMPACT-VIDEO-RENDERER"||el.tagName=="YTD-GRID-VIDEO-RENDERER"||el.tagName=="YTD-VIDEO-RENDERER"){
            return $(el)[0];
        }else{
            return getVideoElement(el.parentNode);
        }
    }
    
    
    function getCreator(el){
        return el.getElementsByClassName("yt-simple-endpoint style-scope yt-formatted-string")[0];
    }
    
    function check(el,blacklist,whitelist,limitgray,limitremove){
        el = $(el);
        var matches = el.attr('class').match(/YouBlock\d+/g);
        $.each(matches, function(){
            var className = this;
            el.removeClass(className.toString());
        });
        el = el[0];
        var titleText = el.textContent;
        var vidId = getId(el);
        var score = getScore(titleText,vidId);
        var vidEl = getVideoElement(el);
        var creator = getCreator(vidEl);
        if ((window.location.href.indexOf("channel")!=-1)&&(typeof creator != "undefined")){
            if(blacklist.indexOf(creator.textContent)!=-1) {
                removeElem(titles[i]);
                edited = true;
            }
            if((whitelist.indexOf(creator.textContent)!=-1)&&(typeof creator != "undefined")) return true;
        }
        vidEl = $(vidEl);
        var edited = false;
        if (+score>+limitgray){
            vidEl.addClass("blurred");
            edited = true;
        }
        if (+score>+limitremove){
            vidEl.addClass("removed");
            edited = true;
        }
        
        vidEl.addClass("YouBlock"+score);
        vidEl.addClass("YouBlockScore");
        
        if(edited) {
            chrome.runtime.sendMessage({videoplus: true}, function(response) {});
        }
        return edited;
    }
    
    
    function main(){
        chrome.storage.local.get(function(result){
            
            var style = result.style;
            var blacklist = result.blacklist || "";
            blacklist = blacklist.split("/n");
            var whitelist = result.whitelist || "";
            whitelist = whitelist.split("/n");
            var limitgray = result.gray;
            var limitremove = result.remove;
            
            var watch = (window.location.href.indexOf("watch")!=-1);
            
            var titles = [];
            var creators = [];
            
            if (watch){
                titles = $("h3.style-scope.ytd-compact-video-renderer span.style-scope.ytd-compact-video-renderer").not(".YouBlockScore *");
            }else{
                
                titles = $(".yt-simple-endpoint.style-scope.ytd-grid-video-renderer").not(".YouBlockScore *");
                $(titles).add(".yt-simple-endpoint.style-scope.ytd-video-renderer").not(".YouBlockScore *");
                $(titles).add("span.style-scope.ytd-playlist-video-renderer").not(".YouBlockScore *");
            }
            
            titles.each(function(i){
                titles[i].YouBlockId = getId(titles[i]);
            });
            
            titles.each(function(i){
                check(titles[i],blacklist,whitelist,limitgray,limitremove);
            });
            
            var edited = false;
            do{
                titles.each(function(i){
                    if(titles[i].YouBlockId != getId(titles[i])){
                        if(check(titles[i],blacklist,whitelist,limitgray,limitremove)&&!edited){
                            edited = true;
                        }
                    }
                });
            }while(edited);
        });           
    }
    
    chrome.storage.local.get(function(result){
        
        if(localStorage.timer){
            clearInterval(localStorage.timer);
        }
        
        localStorage.timer=setInterval(function(){
            main();
        },result.interval*1000);
        chrome.runtime.sendMessage({videonull: true}, function(response) {});

        main();
        
    });
