
document.onbeforeunload = function(){
    chrome.storage.local.get(function(result){
        if(localStorage.timer){
            clearInterval(localStorage.timer);
        }
    });
};
chrome.storage.local.get(function(result){
    if(result.enabled){
        var script = document.createElement('script');
        script.src = 'https://code.jquery.com/jquery-3.2.1.min.js';
        script.type = 'text/javascript';
        document.getElementsByTagName('head')[0].appendChild(script);

        function getScore(title,id) {
            var tmp = null;
            $.ajax({
                async: false,
                type: "POST",
                global: false,
                crossDomain: true,
                dataType: "html",
                data: { 'request': "", 'target': 'arrange_url', 'method': 'method_target' },
                url:   "https://youclick.fr/analyse.php?onlytitle=true&title="+title+"&videoID="+id,
                success: function (data) {
                    tmp = data;
                }
            });
            return tmp;
        }
        function getId(el){
            if(el.href){
                return el.href.split("?v=")[1].split("&")[0];
            }else{
                return (getId(el.parentNode));
            }
        }
        
        function getVideoElement(el){
            if(el==null){return null;}
            if(el.tagName=="YTD-COMPACT-VIDEO-RENDERER"||el.tagName=="YTD-GRID-VIDEO-RENDERER"||el.tagName=="YTD-VIDEO-RENDERER"){
                return $(el);
            }else{
                return getVideoElement(el.parentNode);
            }
        }
        
        function main(){
            $(document).ready(function(){
            
                var style = result.style;
                var blacklist = result.blacklist || "";
                blacklist = blacklist.split("/n");
                var whitelist = result.whitelist || "";
                whitelist = whitelist.split("/n");
                var limitgray = result.gray;
                var limitremove = result.remove;
                
                var watch = (window.location.href.indexOf("watch")!=-1);
                
                var titles = [];
                var creators = [];
                
                if (watch){
                    titles = $("h3.style-scope.ytd-compact-video-renderer span.style-scope.ytd-compact-video-renderer").not(".YouBlockScore *");
                    creators = $("div.style-scope.ytd-video-meta-block yt-formatted-string.style-scope.ytd-video-meta-block").not(".YouBlockScore *");
                }else{
                    
                    titles = $(".yt-simple-endpoint.style-scope.ytd-grid-video-renderer");
                    $(titles).add(".yt-simple-endpoint.style-scope.ytd-video-renderer");
                    $(titles).add("span.style-scope.ytd-playlist-video-renderer");
                    titles = $(titles).not(".YouBlockScore *");
                    creators = $(".yt-simple-endpoint.style-scope.yt-formatted-string").not(".YouBlockScore *").toArray();
                    creators.pop();
                    creators.pop();
                    creators = $(creators);
                }
                for(i=0;i<creators.length;i++){
                    if(creators[i].innerHTML==""){
                        creators.splice(i,1);
                    }
                }
                while(creators.length<titles.length){
                    creators.push(creators[creators.length-1]);
                }
                console.log(titles);
                console.log(creators);
                
                titles.each(function(i) {
                    var titleText = $(titles[i]).text();
                    var vidId = getId(titles[i]);
                    var score = getScore(titleText,vidId);
                    console.log(vidId);
                    console.log(titleText);
                    console.log(score);
                    if ((window.location.href.indexOf("channel")!=-1)&&(typeof creators[i] != "undefined")){
                        if(blacklist.indexOf($(creators[i]).text())!=-1) {
                            removeElem(titles[i]);
                            edited = true;
                            console.log("blacklist");
                        }
                        if((whitelist.indexOf($(creators[i]).text())!=-1)&&(typeof creators[i] != "undefined")) return true;
                    }
                    var edited = false;
                    if (+score>+limitgray){
                        getVideoElement(titles[i]).addClass("blurred");
                        edited = true;
                        console.log("grayed");
                    }
                    if (+score>+limitremove){
                        getVideoElement(titles[i]).addClass("removed");
                        edited = true;
                        console.log("removed");
                    }
                    
                    getVideoElement(titles[i]).addClass("YouBlock"+score);
                    getVideoElement(titles[i]).addClass("YouBlockScore");

                    if(edited) {
                        chrome.runtime.sendMessage({videoplus: true}, function(response) {});
                    }
                });
            });
        }
           
        if(localStorage.timer){
            clearInterval(localStorage.timer);
        }
        localStorage.timer=setInterval(function(){
            main();
        },result.interval*1000);
        chrome.runtime.sendMessage({videonull: true}, function(response) {});

        main();
    }
});
