var currentUrl = "";
var newUrl = "";
function checkUrl() {
	chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
		var currentTab = tabs[0];
		if(currentTab.url.indexOf("youtube")!=-1){
			newUrl = currentTab.url;
			if(newUrl!=currentUrl){
				currentUrl = newUrl;
				chrome.tabs.executeScript(null, { file: "jquery.js" });
				chrome.tabs.executeScript(null, { file: "load-blocker.js" });
			}
		}
	});
	
}

setInterval(checkUrl, 1000);

chrome.runtime.onInstalled.addListener(function(details){
    if(details.reason == "install"){
        chrome.storage.local.set({
			gray: 50,
			remove: 100,
			pro: true,
			excreators: null,
			exstrings: null,
			style: 0
		});
    }
});

chrome.runtime.onMessageExternal.addListener(
	function(request, sender, sendResponse) {
		document.write(request);
		if (request.purchased){
			chrome.storage.local.set({pro: true});
			sendResponse({success: true});
		}
		if (request.block) {
			chrome.storage.local.set({excreators: request.newex});
			sendResponse({success: true});
		}
	}
);