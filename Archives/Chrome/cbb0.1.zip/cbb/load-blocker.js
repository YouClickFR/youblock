try{
	function checkNew() {
		if(document.getElementsByClassName(" yt-ui-ellipsis yt-ui-ellipsis-2 yt-uix-sessionlink spf-link ").length!=$("meta[name='YouBlockCount']").attr('content')){
			$.loadScript(chrome.extension.getURL("blocker.js"));
		}
	}
	function checkNewWatch() {
		if($("span.title").length!=$("meta[name='YouBlockCount']").attr('content')){
			$.loadScript(chrome.extension.getURL("blocker-watch.js"));	
			$.loadScript(chrome.extension.getURL("addButtons.js"));
		}
	}
	function checkNewNew() {
		if($(".yt-simple-endpoint.style-scope.ytd-grid-video-renderer, .yt-simple-endpoint.style-scope.ytd-video-renderer").length!=$("meta[name='YouBlockCount']").attr('content')){
			$.loadScript(chrome.extension.getURL("blocker-new.js"));
		}
	}
	function checkNewWatchNew() {
		if($("h3.style-scope.ytd-compact-video-renderer span.style-scope.ytd-compact-video-renderer").length!=$("meta[name='YouBlockCount']").attr('content')){
			$.loadScript(chrome.extension.getURL("blocker-watch-new.js"));
		}
	}
	
	if(timer){
		clearInterval(timer);
	}else{
		var timer;
	}
	$("meta[name='YouBlockCount']").remove();
	clearInterval(localStorage.YouBlockTimer);
	$.loadScript = function (url) {
		$.ajax({
			url: url,
			dataType: 'script',
			async: true
		});
	}
	url=window.location.href;
	chrome.storage.local.get("excreators", function(result) {
		localStorage.setItem("YouBlockExcreators", result.excreators);
	});
	chrome.storage.local.get("exstrings", function(result) {
		localStorage.setItem("YouBlockExstrings", result.exstrings);
	});
	chrome.storage.local.get("gray", function(result) {
		localStorage.setItem("YouBlockGray", result.gray);
	});
	chrome.storage.local.get("remove", function(result) {
		localStorage.setItem("YouBlockRemove", result.remove);
	});
	chrome.storage.local.get("pro", function(result) {
		localStorage.setItem("YouBlockPro", result.pro);
	});
	chrome.storage.local.get("style", function(result) {
		if(result.style==0){
			if(url.indexOf("watch")!=-1){
				$.loadScript(chrome.extension.getURL("jquery.js"));
				$.loadScript(chrome.extension.getURL("blocker-watch.js"));
				$.loadScript(chrome.extension.getURL("addButtons.js"));
				timer = setInterval(checkNewWatch,1000);
			}else{
				$.loadScript(chrome.extension.getURL("jquery.js"));
				$.loadScript(chrome.extension.getURL("blocker.js"));
				timer = setInterval(checkNew,1000);
			}
		}else{
			if(url.indexOf("watch")!=-1){
				$.loadScript(chrome.extension.getURL("jquery.js"));
				$.loadScript(chrome.extension.getURL("blocker-watch-new.js"));
				timer = setInterval(checkNewWatchNew,1000);
			}else{
				$.loadScript(chrome.extension.getURL("jquery.js"));
				$.loadScript(chrome.extension.getURL("blocker-new.js"));
				timer = setInterval(checkNewNew,1000);
			}
		}
	});

}catch (err){
	alert(err);
}