
function saveOptions(e) {
	e.preventDefault();
	exc = document.getElementById("text2").value;
	if(exc==""){
		exc=null;
	}
	chrome.storage.local.set({
		excreators: exc
	});
	exs = document.getElementById("text1").value;
	if(exs==""){
		exs=null;
	}
	chrome.storage.local.set({
		exstrings: exs
	});
	chrome.storage.local.set({
		gray: document.getElementById("slide1").value
	});
	chrome.storage.local.set({
		remove: document.getElementById("slide2").value
	});
	chrome.storage.local.set({
		style: document.getElementById("switch").value
	});
	
}

function restoreOptions() {
	function setCurrentChoice(stored) {
		document.getElementById("text2").value = stored.excreators || "";
		document.getElementById("text1").value = stored.exstrings || "";
		document.getElementById("slide1").value = stored.gray || "0";
		document.getElementById("score1").innerHTML = stored.gray || "ERROR";
		document.getElementById("slide2").value = stored.remove || "0";
		document.getElementById("score2").innerHTML = stored.remove || "ERROR";
		document.getElementById("switch").value = stored.style || "0";
		var pro = stored.pro;
		if (!pro){
			document.getElementById("text1lab").innerHTML+=" (For Pro only)";
			document.getElementById("text2lab").innerHTML+=" (For Pro only)";
			document.getElementById("text1lab").className+=" disabled";
			document.getElementById("text2lab").className+=" disabled";
			document.getElementById("text1").disabled=true;
			document.getElementById("text2").disabled=true;
		}
	}
	chrome.storage.local.get(setCurrentChoice);
}


document.addEventListener("DOMContentLoaded", restoreOptions);
document.querySelector("#savebtn").addEventListener("click", saveOptions);

