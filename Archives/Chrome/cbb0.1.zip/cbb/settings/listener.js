document.getElementById('slide1').addEventListener('change', function() {
    document.getElementById('score1').innerHTML=document.getElementById('slide1').value;
}, false);
document.getElementById('slide2').addEventListener('change', function() {
    document.getElementById('score2').innerHTML=document.getElementById('slide2').value;
}, false);
document.getElementById("purchasebtn").addEventListener("click", function() {chrome.tabs.create({url: "https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=96CJHFWN7K5JS"});});
document.getElementById("donatebtn").addEventListener("click", function() {chrome.tabs.create({url: "https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=YMG6YX4VYR35G"});});
document.getElementById("donatespanbtn").addEventListener("click", function() {
	span=document.getElementById("donatespan");
	if(span.style.display == "block"){
		span.style.display = "none";
	}else{
		span.style.display = "block"; 
	}
	span=document.getElementById("creditspan");
	if(span.style.display == "block"){
		span.style.display = "none";
	}
	span=document.getElementById("contactspan");
	if(span.style.display == "block"){
		span.style.display = "none";
	}
}); 
document.getElementById("contactbtn").addEventListener("click", function() {
	span=document.getElementById("contactspan");
	if(span.style.display == "block"){
		span.style.display = "none";
	}else{
		span.style.display = "block"; 
	}
	span=document.getElementById("creditspan");
	if(span.style.display == "block"){
		span.style.display = "none";
	}
	span=document.getElementById("donatespan")
	if(span.style.display == "block"){
		span.style.display = "none";
	}
}); 
document.getElementById("creditbtn").addEventListener("click", function() {
	span=document.getElementById("creditspan");
	if(span.style.display == "block"){
		span.style.display = "none";
	}else{
		span.style.display = "block"; 
	}
	span=document.getElementById("contactspan");
	if(span.style.display == "block"){
		span.style.display = "none";
	}
	span=document.getElementById("donatespan")
	if(span.style.display == "block"){
		span.style.display = "none";
	}
});
