try{
	function getCreator() {
		var json = JSON.parse($("script[type='application/ld+json']")[0].innerText);
		return json['itemListElement'][0]['item']['name'];
	}
	$(document).ready();
	function onError(error) {
		console.log("Error: ${error}");
	}
	function toggle(){
		var pro = localStorage.YouBlockPro;
		if(!pro) {
			alert("This feature is only available in pro version. You can purchase it for 1€ in the config-page under 'More..'/'Donate&Purchase Pro'/'Buy Pro (1€)'");
		}
		var listed = localStorage.YouBlockExcreators;
		var creator = getCreator();
		console.log(creator);
		console.log(listed);
		var newExc = "";
		if(!listed||listed==null||listed=="null"||listed==undefined||listed=="undefined"){
			newExc=creator;
		}else{
			listed=listed.split("\n");
			var contains = false;
			for(i=0; i<listed.length;i++){
				if(listed[i]==creator){
					contains = true;
				}
			}
			if(contains){
				listed.splice(listed.indexOf(creator),1);
			}else{
				listed.push(creator);
			}
			newExc=listed[0];
			for(i=1;i<listed.length;i++){
				newExc+="\n"+listed[i];
			}
		}
		console.log(newExc);
		var id = "dcfnciaclbchealmlnkphmoddmdaaecm";
		chrome.runtime.sendMessage(id, {block: true, newex: newExc},
			function(response) {
				if(!response){
					alert("Error! Contact melzerfinn(at)gmail.com for help. Error: 0x01");
				}else{
					if (!response.success){
						alert("Error! Contact melzerfinn(at)gmail.com for help. Error: 0x02");
					}else{
					}
				}
			}
		);
		localStorage.YouBlockExcreators = newExc;
		var listed = localStorage.YouBlockExcreators;
		var creator = getCreator();
		var text = "";
		if(!listed||listed==null||listed=="null"||listed==undefined||listed=="undefined"){
			text="Block "+creator;
		}else{
			listed=listed.split("\n");
			var contains = false;
			for(i=0; i<listed.length;i++){
				if(listed[i]==creator){
					contains = true;
				}
			}
			if(contains){
				text="Unblock "+creator;
			}else{
				text="Block "+creator;
			}
			newExc=listed[0];
			for(i=1;i<listed.length;i++){
				newExc+="\n"+listed[i];
			}
		}
		document.getElementById("toggleblockbtn").innerHTML = text;
	}
	if (!document.getElementById("toggleblockbtn")){
		var buttondiv = document.getElementById("watch8-secondary-actions");
		buttondiv.innerHTML += "<button id=\"toggleblockbtn\" class=\"yt-uix-button yt-uix-button-size-default yt-uix-button-opacity yt-uix-tooltip\" type=\"button\" data-button-toggle=\"true\" data-tooltip-text=\"Add/remove this Youtuber to/from blacklist\" aria-labelledby=\"yt-uix-tooltip1152-arialabel\" title=\"(Un-)block this Youtuber\"><span class=\"yt-uix-button-content\">(Un-)block this Youtuber</span></button>";
		document.getElementById("toggleblockbtn").addEventListener("click", toggle);
		var listed = localStorage.YouBlockExcreators;
		var creator = getCreator();
		var text = "";
		if(!listed||listed==null||listed=="null"||listed==undefined||listed=="undefined"){
			text="Block "+creator;
		}else{
			listed=listed.split("\n");
			var contains = false;
			for(i=0; i<listed.length;i++){
				if(listed[i]==creator){
					contains = true;
				}
			}
			if(contains){
				text="Unblock "+creator;
			}else{
				text="Block "+creator;
			}
			newExc=listed[0];
			for(i=1;i<listed.length;i++){
				newExc+="\n"+listed[i];
			}
		}
		document.getElementById("toggleblockbtn").innerHTML = text;
	}
	
}catch(err){
	console.log(err);
}