console.log("1");

function extractScore(str) {
	return str.match("/\d+/")[0];
}
function getScore(title) {
	var tmp = null;
	$.ajax({
		async: false,
		type: "POST",
		global: false,
		crossDomain: true,
		dataType: "html",
		data: { 'request': "", 'target': 'arrange_url', 'method': 'method_target' },
		url:  "https://youclick.fr/?onlytitle=true&title="+title,
		success: function (data) {
			tmp = data;
		}
	});
	console.log(tmp+"   "+title);
	return tmp;
}
function getStored(name){
	if(name=="excreators") {
		return localStorage.YouBlockExcreators;
	}else if (name=="exstrings") {
		return localStorage.YouBlockExstrings;
	}else if (name=="gray") {
		return localStorage.YouBlockGray;
	}else if (name=="remove") {
		return localStorage.YouBlockRemove;
	}
}
function removeElem(el){
	if(el==null){return;}
	if(el.tagName=="YTD-GRID-VIDEO-RENDERER"||el.tagName=="YTD-VIDEO-RENDERER"){
		//$(el).addClass("removed");
		//$(el).remove();
		$(el).attr("style","display:none;")
	}else{
		try{
		removeElem(el.parentNode);
		}catch(err){console.log(err);}
	}
}
function blurElem(el){
	if(el==null){return;}
	if(el.tagName=="YTD-GRID-VIDEO-RENDERER"||el.tagName=="YTD-VIDEO-RENDERER"){
		$(el).addClass("blurred");
	}else{
		try{
			console.log(el);
		blurElem(el.parentNode);
		}catch(err){}
	}
}
getScore("abc");
function main(){
	try{
		if(!$("meta[name='YouBlockCount']").length){
			$("head").append("<meta name='YouBlockCount' content='0'>")
			var count = 0;
		}else{
			var count = $("meta[name='YouBlockCount']").attr('content');
		}
		var excreators = getStored("excreators");
		if(!excreators){
			excreators = [];
		} else {
			excreators = excreators.split("\n");
		}
		var exstrings = getStored("exstrings");
		if(!exstrings){
			exstrings = [];
		} else {
			exstrings = exstrings.split("\n");
		}
		var limitGray = getStored("gray");
		var limitRemove = getStored("remove");
		console.log(excreators);
		console.log(exstrings);
		console.log(limitGray);
		console.log(limitRemove);
		
		var titles = $(".yt-simple-endpoint.style-scope.ytd-grid-video-renderer, .yt-simple-endpoint.style-scope.ytd-video-renderer");
		var creators = $(".yt-simple-endpoint.style-scope.yt-formatted-string").not("bold").toArray();
		creators.pop();
		creators.pop();

		var lengtit = titles.length;
		var lengexs = exstrings.length;

		for(i=count;i<lengtit;i++){
			var titleText = titles[i].innerHTML;
			var score = getScore(titleText);
			titles[i].innerHTML = "["+score+"] "+titleText;
			for(j=0;j<lengexs;j++) {
				if(titleText.toLowerCase().indexOf(exstrings[j].toLowerCase())!=-1){
					removeElem(titles[i]);
				}
			}
			if(excreators.indexOf(creators[i])!=-1) {
				removeElem(titles[i]);
			}
			if(+score>+limitGray) {
				blurElem(titles[i]);
				console.log("blurred: "+ titleText);
			}
			if(+score>+limitRemove) {
				removeElem(titles[i]);
				console.log("removed: "+ titleText);
			}
		}
		$("meta[name='YouBlockCount']").attr('content',titles.length);
	}catch(err){
		console.log(err);
	}
}
main();
