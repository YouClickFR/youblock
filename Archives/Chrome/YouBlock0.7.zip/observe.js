chrome.runtime.onInstalled.addListener(function(details){
    if(details.reason == "install"){
        chrome.storage.local.set({
			gray: 100,
			remove: 130,
			pro: true,
			blacklist: null,
            wordlist: null,
			whitelist: null,
			interval: 1.5,
			enabled: true
		});
    }else{
		chrome.storage.local.get(function(result){
			if(typeof result.gray == 'undefined') chrome.storage.local.set({gray: 100});
			if(typeof result.remove == 'undefined') chrome.storage.local.set({remove: 130});
			if(typeof result.blacklist == 'undefined') chrome.storage.local.set({blacklist: null});
			if(typeof result.whitelist == 'undefined') chrome.storage.local.set({whitelist: null});
			if(typeof result.interval == 'undefined') chrome.storage.local.set({interval: 1.5});
			if(typeof result.enabled == 'undefined') chrome.storage.local.set({enabled: true});
		});
	}
});

chrome.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		console.log(request);
		if (request.videoplus){
			chrome.browserAction.getBadgeText({tabId: sender.tab.id},function(badgecount){
				if (!badgecount){
					text = "1";
				}else{
					text = +badgecount+1;
					text = ""+text;
				}
				chrome.browserAction.getBadgeText({},function(badgecount){
					chrome.browserAction.setBadgeText({text: text, tabId: sender.tab.id});
				});
			});
			sendResponse({added: "Count +1"});
		}
		if (request.videonull){
			chrome.browserAction.getBadgeText({},function(badgecount){
				chrome.browserAction.setBadgeText({text: "", tabId: sender.tab.id});
			});
			sendResponse({added: "Count 0"});
		}
	}
);
