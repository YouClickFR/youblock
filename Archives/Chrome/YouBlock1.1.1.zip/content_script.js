document.onbeforeunload = function () {
    chrome.storage.local.get(function (result) {
        if (localStorage.timer) {
            clearInterval(localStorage.timer);
        }
    });
    clearYtCache();
};

chrome.storage.local.get(function (result) {
    if (!result.enabled) { return; }
});

function getScore(titleText, vidId, limitgray, limitremove, vidEl, version, page) {
    var tmp = null;
    $.ajax({
        global: false,
        dataType: "html",
        data: { 'request': "", 'target': 'arrange_url', 'method': 'method_target' },
        url: "https://youclick.fr/analyse.php?onlytitle=true&title=" + titleText + "&videoID=" + vidId + "&ver=" + version + "&page=" + page,
        success: function (data) {
            applyScore(vidEl, limitgray, limitremove, data);
        }
    });
}

var subscriptions = "";
async function updateSubs() {
    subscriptions = "";
    $("yt-formatted-string").each(function () {
        if ((new RegExp("sign in", "i")).test(this.innerText)) {
            subscriptions = [];
        }
    });
    if (typeof subscriptions == "string") $.ajax({
        dataType: "text",
        success: function (data) {
            m1 = data.match(/text="[^"]+" title="[^"]+" type="rss"/g);
            m2 = [];
            if (m1 != null) {
                m1.forEach(s => {
                    m2.push(s.match(/"[^"]+"/g)[0]);
                });
                for (i = 0; i < m2.length; i++) {
                    m2[i] = m2[i].substring(1, m2[i].length - 1);
                }
            }
            subscriptions = m2;
        },
        url: "https://www.youtube.com/subscription_manager?action_takeout=1"
    });
}

function getId(el) {
    if (el.href) {
        return el.href.split("?v=")[1].split("&")[0];
    } else {
        return (getId(el.parentNode));
    }
}


function getVideoElement(el) {
    if (el == null) { return null; }
    if (el.tagName == "YTD-COMPACT-VIDEO-RENDERER" || el.tagName == "YTD-GRID-VIDEO-RENDERER" || el.tagName == "YTD-VIDEO-RENDERER") {
        return $(el);
    } else {
        return getVideoElement(el.parentNode);
    }
}


function getCreator(el) {
    var tmp = el.find(".yt-simple-endpoint.style-scope.yt-formatted-string")[0];
    if (tmp) return tmp.textContent;
    tmp = el.find("yt-formatted-string.style-scope.ytd-video-meta-block")[0];
    if (tmp) return tmp.textContent;
    return null;
}

function isBlacklisted(title, creator, wordlist, blacklist) {
    if (title != null) if (title.length < 1) {
        for (i = 0; i < wordlist.length; i++) {
            if (wordlist[i] != "") if ((new RegExp(wordlist[i], "i")).test(title)) return true;
        }
    }
    if (creator != null) {
        for (i = 0; i < blacklist.length; i++) {
            if ((new RegExp(blacklist[i], "i")).test(creator)) return true;
        }
    }
    return false;
}

function isWhitelisted(creator, whitelist) {
    if (creator == null) return false;
    for (i = 0; i < whitelist.length; i++) {
        if ((new RegExp(whitelist[i], "i")).test(creator)) return true;
    }
    return false;
}

function isSubscribed(creator) {
    if (creator == null) return false;
    for (i = 0; i < subscriptions.length; i++) {
        if ((new RegExp(subscriptions[i], "i")).test(creator)) {
            return true;
        }
    }
    return false;
}

async function check(el, blacklist, wordlist, whitelist, limitgray, limitremove, version, page) {
    var titleText = el.textContent.trim();
    var vidId = getId(el);
    var vidEl = getVideoElement(el);
    var creator = getCreator(vidEl);
    if (isWhitelisted(creator, whitelist)) {
        vidEl.addClass("YouBlock");
        vidEl.addClass("YouBlockWhitelist");
    } else if (isBlacklisted(titleText, creator, wordlist, blacklist)) {
        vidEl.addClass("YouBlock");
        vidEl.addClass("removed");
        chrome.runtime.sendMessage({ videoplus: true }, function (response) { });
    } else if (isSubscribed(creator)) {
        vidEl.addClass("YouBlock");
        vidEl.addClass("YouBlockSubscribed");
    } else
        getScore(titleText, vidId, limitgray, limitremove, vidEl, version, page);
}

function applyScore(vidEl, limitgray, limitremove, score) {
    if ((new RegExp(/youtube\.[^\/]*(\/feed\/subscriptions\/|\/user\/|\/feed\/channels\/|\/channel\/)/i)).test(window.location.href)) {
            return;
        }
    if (+score > +limitgray && +limitgray > 0) {
        vidEl.addClass("blurred");
        chrome.runtime.sendMessage({ videoplus: true }, function (response) { });
    }
    if (+score > +limitremove && +limitremove > 0) {
        vidEl.addClass("removed");
        chrome.runtime.sendMessage({ videoplus: true }, function (response) { });
    }

    vidEl.addClass("YouBlock" + score);
    vidEl.addClass("YouBlock");
}

function clearYtCache() {
    $("ytd-page-manager > :hidden").remove();
}

function main() {
    chrome.storage.local.get(function (result) {
        updateSubs();
        clearYtCache();
        if (result.enabled == false) {
            throw new Error("YouBlock disabled");
        }
        if (result.forcereload) {
            if (localStorage.getItem("lasturl") != window.location.href) {
                localStorage.setItem("lasturl", window.location.href);
                window.location.reload(true);
            }
        }
        if ((new RegExp(/youtube\.[^\/]*(\/feed\/subscriptions\/|\/user\/|\/feed\/channels\/|\/channel\/)/i)).test(window.location.href)) {
            return;
        }
        var style = result.style;

        var blacklist = result.blacklist || "";
        if (blacklist != "") {
            blacklist = blacklist.split(", ");
        } else blacklist = [];

        var wordlist = result.wordlist || "";
        if (wordlist != "") {
            wordlist = wordlist.split(", ");
        } else wordlist = [];

        var whitelist = result.whitelist || "";
        if (whitelist != "") {
            whitelist = whitelist.split(", ");
        } else whitelist = [];

        var YouClickWhite = result.YouClickWhite || "";
        if (YouClickWhite != "") {
            YouClickWhite = YouClickWhite.split(", ");
        } else YouClickWhite = [];

        whitelist = whitelist.concat(YouClickWhite);

        var YouClickBlack = result.YouClickBlack || "";
        if (YouClickBlack != "") {
            YouClickBlack = YouClickBlack.split(", ");
        } else YouClickBlack = [];

        blacklist = blacklist.concat(YouClickBlack);

        var limitgray = result.gray;
        var limitremove = result.remove;

        var version = chrome.runtime.getManifest().version;
        var page = window.location.pathname;

        var watch = (window.location.pathname.indexOf("watch") != -1);

        var titles = [];
        var creators = [];

        if (watch) {
            titles = $("h3.style-scope.ytd-compact-video-renderer span.style-scope.ytd-compact-video-renderer").not(".YouBlock *");
        } else {
            titles = $(".yt-simple-endpoint.style-scope.ytd-grid-video-renderer").not(".YouBlock *").add(".yt-simple-endpoint.style-scope.ytd-video-renderer").not(".YouBlock *");
        }

        function waitUntilDefined() {
            if ((new RegExp(/youtube\.[^\/]*(\/feed\/subscriptions\/|\/user\/|\/feed\/channels\/|\/channel\/)/i)).test(window.location.href)) {
                return;
            }
            if (typeof subscriptions == "object") {
                titles.each(function (i) {
                    check(titles[i], blacklist, wordlist, whitelist, limitgray, limitremove, version, page);
                });
            } else {
                setTimeout(waitUntilDefined, 100);
            }
        }

        waitUntilDefined();
    });
}

function loadCss() {
    chrome.storage.local.get(function (stored) {
        $('head').append('<style type="text/css">' + stored.css + '</style>');
    });
}

chrome.storage.local.get(function (result) {

    if (localStorage.timer) {
        clearInterval(localStorage.timer);
    }

    localStorage.timer = setInterval(function () {
        main();
    }, result.interval * 1000);
    chrome.runtime.sendMessage({ videonull: true }, function (response) { });
    loadCss();

    main();

});
