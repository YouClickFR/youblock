
    document.onbeforeunload = function(){
        chrome.storage.local.get(function(result){
            if(localStorage.timer){
                clearInterval(localStorage.timer);
            }
        });
    };

    chrome.storage.local.get(function(result){
        if(!result.enabled){ return;}
    });
        
    function getScore(title,id) {
        var tmp = null;
        $.ajax({
            async: false,
            type: "POST",
            global: false,
            crossDomain: true,
            dataType: "html",
            data: { 'request': "", 'target': 'arrange_url', 'method': 'method_target' },
            url:   "https://youclick.fr/analyse.php?onlytitle=true&title="+title+"&videoID="+id,
            success: function (data) {
                tmp = data;
            }
        });
        return tmp;
    }
    
    
    function getId(el){
        if(el.href){
            return el.href.split("?v=")[1].split("&")[0];
        }else{
            return (getId(el.parentNode));
        }
    }
    
    
    function getVideoElement(el){
        if(el==null){return null;}
        if(el.tagName=="YTD-COMPACT-VIDEO-RENDERER"||el.tagName=="YTD-GRID-VIDEO-RENDERER"||el.tagName=="YTD-VIDEO-RENDERER"){
            return $(el)[0];
        }else{
            return getVideoElement(el.parentNode);
        }
    }
    
    
    function getCreator(el){
        var tmp = el.getElementsByClassName("yt-simple-endpoint style-scope yt-formatted-string")[0];
        if(tmp) return tmp.textContent;
        tmp = $(el).find("yt-formatted-string.style-scope.ytd-video-meta-block")[0];
        if(tmp) return tmp.textContent;
        return null;
    }
    
    function isBlacklisted(title, creator, wordlist, blacklist){
        for(i=0;i<wordlist.length;i++){
            if(wordlist[i]!="") if(title.indexOf(wordlist[i])!=-1) return true;
        }
        if (creator != null) {
            for(i=0;i<blacklist.length;i++){
                if(creator==blacklist[i]) return true;
            }
        }
        return false;
    }
    
    function isWhitelisted(creator, whitelist){
        if (creator == null) return false;
        for(i=0;i<whitelist.length;i++){
            if(creator==whitelist[i]) return true;
        }
        return false;
    }
    
    function check(el,blacklist,wordlist,whitelist,limitgray,limitremove){
        el = $(el);
        var matches = el.attr('class').match(/YouBlock\d+/g);
        $.each(matches, function(){
            var className = this;
            el.removeClass(className.toString());
        });
        el = el[0];
        var titleText = el.textContent;
        var vidId = getId(el);
        var score = getScore(titleText,vidId);
        var vidEl = getVideoElement(el);
        var creator = getCreator(vidEl);
        vidEl = $(vidEl);
        if(isWhitelisted(creator, whitelist)){
            vidEl.addClass("YouBlock");
            vidEl.addClass("YouBlockWhitelist");
            return false;
        }
        if(isBlacklisted(titleText, creator, wordlist, blacklist)){
            vidEl.addClass("YouBlock");
            vidEl.addClass("removed");
            chrome.runtime.sendMessage({videoplus: true}, function(response) {});
            return true;
        }
        var edited = false;
        if (+score>+limitgray&&+limitgray>0){
            vidEl.addClass("blurred");
            edited = true;
        }
        if (+score>+limitremove&&+limitremove>0){
            vidEl.addClass("removed");
            edited = true;
        }
        
        vidEl.addClass("YouBlock"+score);
        vidEl.addClass("YouBlock");
        
        if(edited) {
            chrome.runtime.sendMessage({videoplus: true}, function(response) {});
        }
        return edited;
    }
    
    
    function main(){
        chrome.storage.local.get(function(result){
            
            var style = result.style;
            var blacklist = result.blacklist || "";
            blacklist = blacklist.split(", ");
            var wordlist = result.wordlist || "";
            wordlist = wordlist.split(", ");
            var whitelist = result.whitelist || "";
            whitelist = whitelist.split(", ");
            var YouClickWhite = result.YouClickWhite || "";
            whitelist = whitelist.concat(YouClickWhite.split(", "));
            var YouClickBlack = result.YouClickBlack || "";
            blacklist = blacklist.concat(YouClickBlack.split(", "));
            var limitgray = result.gray;
            var limitremove = result.remove;
            
            console.log(blacklist);
            
            var watch = (window.location.pathname.indexOf("watch")!=-1);
            
            var titles = [];
            var creators = [];
            
            if (watch){
                titles = $("h3.style-scope.ytd-compact-video-renderer span.style-scope.ytd-compact-video-renderer").not(".YouBlock *");
            }else{
                
                titles = $(".yt-simple-endpoint.style-scope.ytd-grid-video-renderer").not(".YouBlock *");
                $(titles).add(".yt-simple-endpoint.style-scope.ytd-video-renderer").not(".YouBlock *");
            }
            
            titles.each(function(i){
                titles[i].YouBlockId = getId(titles[i]);
            });
            
            titles.each(function(i){
                check(titles[i],blacklist,wordlist,whitelist,limitgray,limitremove);
            });
            
            var edited = false;
            do{
                titles.each(function(i){
                    if(titles[i].YouBlockId != getId(titles[i])){
                        check(titles[i],blacklist,wordlist,whitelist,limitgray,limitremove);
                        edited = true;
                    }
                });
            }while(edited);
        });           
    }
    
    chrome.storage.local.get(function(result){
        
        if(localStorage.timer){
            clearInterval(localStorage.timer);
        }
        
        localStorage.timer=setInterval(function(){
            main();
        },result.interval*1000);
        chrome.runtime.sendMessage({videonull: true}, function(response) {});

        main();
        
    });
