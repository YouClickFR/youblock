document.getElementById('slide1').addEventListener('input', function() {
    if(document.getElementById('slide1').value>0){
        document.getElementById('score1').innerHTML=document.getElementById('slide1').value;
    }else{
        document.getElementById('score1').innerHTML="OFF"
    }
});
document.getElementById('slide2').addEventListener('input', function() {
    if(document.getElementById('slide2').value>0){
        document.getElementById('score2').innerHTML=document.getElementById('slide2').value;
    }else{
        document.getElementById('score2').innerHTML="OFF"
    }
});
document.getElementById('slide3').addEventListener('input', function(){
    document.getElementById('score3').innerHTML=document.getElementById('slide3').value+" seconds";
});

document.getElementById('slide1').addEventListener('change', function() {
    if(document.getElementById('slide1').value<1){
        document.getElementById('slide1').value=-45;
        document.getElementById('score1').innerHTML="OFF";
    };
});
document.getElementById('slide2').addEventListener('change', function() {
    if(document.getElementById('slide2').value<1){
        document.getElementById('slide2').value=-45;
        document.getElementById('score2').innerHTML="OFF";
    };
});

document.getElementById("able-switch").addEventListener("change", function(){
    if(document.getElementById("able-switch").checked){
        document.getElementById("able-desc").innerHTML = "Enabled";
        chrome.storage.local.set({enabled: true});
    }else{
        document.getElementById("able-desc").innerHTML = "Disabled";
        chrome.storage.local.set({enabled: false});
    }
});
document.getElementById("contactbtn").addEventListener("click", function() {
    span=document.getElementById("contactspan");
    if(span.style.display == "block"){
        span.style.display = "none";
    }else{
        span.style.display = "block"; 
    }
    span=document.getElementById("creditspan");
    if(span.style.display == "block"){
        span.style.display = "none";
    }
}); 
document.getElementById("creditbtn").addEventListener("click", function() {
    span=document.getElementById("creditspan");
    if(span.style.display == "block"){
        span.style.display = "none";
    }else{
        span.style.display = "block"; 
    }
    span=document.getElementById("contactspan");
    if(span.style.display == "block"){
        span.style.display = "none";
    }
});

