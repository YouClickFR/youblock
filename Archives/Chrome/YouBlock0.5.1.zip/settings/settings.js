
function saveOptions(e) {
    e.preventDefault();
    black = document.getElementById("text1").value;
    if(black==""){
        black=null;
    }
    word = document.getElementById("text2").value;
    if(word==""){
        word=null;
    }
    white = document.getElementById("text3").value+document.getElementById("text4").value;
    if(white==""){
        white=null;
    }
    chrome.storage.local.set({
        blacklist: black
    });
    chrome.storage.local.set({
        wordlist: word
    });
    chrome.storage.local.set({
        whitelist: white
    });
    chrome.storage.local.set({
        gray: document.getElementById("slide1").value
    });
    chrome.storage.local.set({
        remove: document.getElementById("slide2").value
    });
    chrome.storage.local.set({
        interval: document.getElementById("slide3").value
    });
    $('#savedDiv').fadeIn('fast',function() {$('#savedDiv').fadeOut(1000);});
    chrome.tabs.reload();
    
}

function restoreOptions() {
    function setCurrentChoice(stored) {
        document.getElementById("text1").value = stored.blacklist || "";
        document.getElementById("text2").value = stored.wordlist || "";
        document.getElementById("text3").value = stored.whitelist || "";
        document.getElementById("slide1").value = stored.gray || 0;
        document.getElementById("score1").innerHTML = stored.gray || "ERROR";
        document.getElementById("slide2").value = stored.remove|| 0;
        document.getElementById("score2").innerHTML = stored.remove || "ERROR";
        document.getElementById("slide3").value = stored.interval || 1.5;
        document.getElementById("score3").innerHTML = stored.interval || "ERORR";
        document.getElementById("score3").innerHTML = document.getElementById("score3").innerHTML + " seconds";
        document.getElementById("able-switch").checked = stored.enabled;
        if(stored.enabled){
            document.getElementById("able-desc").innerHTML = "Enabled";
        }else{
            document.getElementById("able-desc").innerHTML = "Disabled";
        }
    }
    chrome.storage.local.get(setCurrentChoice);
}


document.addEventListener("DOMContentLoaded", restoreOptions);
document.querySelector("#savebtn").addEventListener("click", saveOptions);

