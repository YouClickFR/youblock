chrome.runtime.onInstalled.addListener(function(details){
    if(details.reason == "install"){
        chrome.storage.local.set({
            gray: 100,
            remove: 130,
            pro: true,
            blacklist: null,
            wordlist: null,
            whitelist: null,
            interval: 1.5,
            enabled: true
        });
    }else{
        chrome.storage.local.get(function(result){
            if(typeof result.gray == 'undefined') chrome.storage.local.set({gray: 100});
            if(typeof result.remove == 'undefined') chrome.storage.local.set({remove: 130});
            if(typeof result.blacklist == 'undefined') chrome.storage.local.set({blacklist: null});
            if(typeof result.whitelist == 'undefined') chrome.storage.local.set({whitelist: null});
            if(typeof result.interval == 'undefined') chrome.storage.local.set({interval: 1.5});
            if(typeof result.enabled == 'undefined') chrome.storage.local.set({enabled: true});
        });
    }
});

chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        console.log(request);
        if (request.videoplus){
            chrome.browserAction.getBadgeText({tabId: sender.tab.id},function(badgecount){
                if (!badgecount){
                    text = "1";
                }else{
                    text = +badgecount+1;
                    text = ""+text;
                }
                chrome.browserAction.getBadgeText({},function(badgecount){
                    chrome.browserAction.setBadgeText({text: text, tabId: sender.tab.id});
                });
            });
            sendResponse({added: "Count +1"});
        }
        if (request.videonull){
            chrome.browserAction.getBadgeText({},function(badgecount){
                chrome.browserAction.setBadgeText({text: "", tabId: sender.tab.id});
            });
            sendResponse({added: "Count 0"});
        }
    }
);

var black;
$.ajax({
    async: false,
    type: "POST",
    global: false,
    crossDomain: true,
    dataType: "html",
    data: { 'request': "", 'target': 'arrange_url', 'method': 'method_target' },
    url:   "https://youclick.fr/youblock/blacklisted.yb",
    success: function (data) {
        black = data;
    }
});
var white;
$.ajax({
    async: false,
    type: "POST",
    global: false,
    crossDomain: true,
    dataType: "html",
    data: { 'request': "", 'target': 'arrange_url', 'method': 'method_target' },
    url:   "https://youclick.fr/youblock/whitelisted.yb",
    success: function (data) {
        white = data;
    }
});
chrome.storage.local.set({YouClickWhite: white});
chrome.storage.local.set({YouClickFullBlack: black});
chrome.storage.local.get(function(stored){
    if(!stored.YouClickBlack){
        chrome.storage.local.set({YouClickBlack: stored.YouClickFullBlack});  
    }
    var YouClickFullBlack = stored.YouClickFullBlack || "";
    YouClickFullBlack = YouClickFullBlack.split(", ");
    var YouClickNotBlack = stored.YouClickNotBlack || "";
    YouClickNotBlack = YouClickNotBlack.split(", ");
    var YouClickBlack = [];

    console.log(YouClickFullBlack);
    
    for (i=0; i<YouClickFullBlack.length; i++){
        if(!YouClickNotBlack.includes(YouClickFullBlack[i])){
            YouClickBlack.push(YouClickFullBlack[i]);
            console.log(YouClickBlack);
        }
    }
    var YouClickBlackStr = "";
    for(i=0; i<YouClickBlack.length; i++){
        YouClickBlackStr += YouClickBlack[i]+", ";
    }
    if(YouClickBlackStr!="") YouClickBlackStr = YouClickBlackStr.substring(0, YouClickBlackStr.length-2);
    chrome.storage.local.set({
        YouClickBlack: YouClickBlackStr
    });
    console.log(YouClickBlackStr);
});
