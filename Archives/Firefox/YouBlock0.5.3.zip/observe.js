browser.runtime.onInstalled.addListener(function(details){
    if(details.reason == "install"){
        browser.storage.local.set({
			gray: 100,
			remove: 130,
			pro: true,
			blacklist: null,
            wordlist: null,
			whitelist: null,
			interval: 1.5,
			enabled: true
		});
    }else{
		browser.storage.local.get(function(result){
			if(typeof result.gray == 'undefined') browser.storage.local.set({gray: 100});
			if(typeof result.remove == 'undefined') browser.storage.local.set({remove: 130});
			if(typeof result.blacklist == 'undefined') browser.storage.local.set({blacklist: null});
			if(typeof result.whitelist == 'undefined') browser.storage.local.set({whitelist: null});
			if(typeof result.interval == 'undefined') browser.storage.local.set({interval: 1.5});
			if(typeof result.enabled == 'undefined') browser.storage.local.set({enabled: true});
		});
	}
});

browser.runtime.onMessage.addListener(
	function(request, sender, sendResponse) {
		console.log(request);
		if (request.videoplus){
			browser.browserAction.getBadgeText({tabId: sender.tab.id},function(badgecount){
				if (!badgecount){
					text = "1";
				}else{
					text = +badgecount+1;
					text = ""+text;
				}
				browser.browserAction.getBadgeText({},function(badgecount){
					browser.browserAction.setBadgeText({text: text, tabId: sender.tab.id});
				});
			});
			sendResponse({added: "Count +1"});
		}
		if (request.videonull){
			browser.browserAction.getBadgeText({},function(badgecount){
				browser.browserAction.setBadgeText({text: "", tabId: sender.tab.id});
			});
			sendResponse({added: "Count 0"});
		}
	}
);
