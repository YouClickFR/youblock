
function saveOptions(e) {
	e.preventDefault();
	black = document.getElementById("text2").value;
	if(black==""){
		black=null;
	}
	browser.storage.local.set({
		blacklist: black
	});
	white = document.getElementById("text1").value;
	if(white==""){
		white=null;
	}
	browser.storage.local.set({
		whitelist: white
	});
	browser.storage.local.set({
		gray: document.getElementById("slide1").value
	});
	browser.storage.local.set({
		remove: document.getElementById("slide2").value
	});
	browser.storage.local.set({
		interval: document.getElementById("slide3").value
	});
	$('#savedDiv').fadeIn('fast',function() {$('#savedDiv').fadeOut(1000);});
	
}

function restoreOptions() {
	function setCurrentChoice(stored) {
		document.getElementById("text2").value = stored.blacklist || "";
		document.getElementById("text1").value = stored.whitelist || "";
		document.getElementById("slide1").value = stored.gray || "0";
		document.getElementById("score1").innerHTML = stored.gray || "ERROR";
		document.getElementById("slide2").value = stored.remove || "0";
		document.getElementById("score2").innerHTML = stored.remove || "ERROR";
		document.getElementById("slide3").value = stored.interval || "";
		document.getElementById("score3").innerHTML = stored.interval || "ERORR";
		document.getElementById("score3").innerHTML = document.getElementById("score3").innerHTML + " seconds";
		document.getElementById("able-switch").checked = stored.enabled;
		if(stored.enabled){
			document.getElementById("able-desc").innerHTML = "Enabled";
		}else{
			document.getElementById("able-desc").innerHTML = "Disabled";
		}
		var pro = stored.pro;
		if (!pro){
			document.getElementById("text1lab").innerHTML+=" (For Pro only)";
			document.getElementById("text2lab").innerHTML+=" (For Pro only)";
			document.getElementById("text1lab").className+=" disabled";
			document.getElementById("text2lab").className+=" disabled";
			document.getElementById("text1").disabled=true;
			document.getElementById("text2").disabled=true;
		}
	}
	browser.storage.local.get(setCurrentChoice);
}


document.addEventListener("DOMContentLoaded", restoreOptions);
document.querySelector("#savebtn").addEventListener("click", saveOptions);

